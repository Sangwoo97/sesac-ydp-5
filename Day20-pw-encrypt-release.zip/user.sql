use sesac;
show tables;
select * from user;
DROP TABLE IF EXISTS user;